delete from users;




 
insert into users (name , email , password , phone , type ) values ('ABC', 'abc@gmail.com', 't1234', '01755352842', 'USER');

insert into users ( name , email , password , phone , type )  values ('DEF', 'def@gmail.com', 'n1234', '01876895719', 'ADMIN');
